function addinput(elem) {
	var value = elem.innerHTML;	
	document.querySelector("#barcode").value += value;
}
