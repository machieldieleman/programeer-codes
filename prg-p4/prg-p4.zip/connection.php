<head>
<?php
$conn = mysqli_connect('localhost', 'root', '', 'programeren-p4');
ob_start();
session_start();
?>
</head>