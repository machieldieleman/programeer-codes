<?php
include 'header.inc.php'
?>
<?php
include 'footer.inc.php'
?>
<html>
<title>vakantie-huisjes</title>
<body>
<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="">Hotels</a></li>
  <li><a href="">Bungalows</a></li>
  <li><a href="">Aanbiedingen</a></li>
  <li><a href="">Contact</a></li>
</ul>
<div class="filteren">filteren</div>
<div class="land"></div>
<div class="prize"></div>
</body>
</html>